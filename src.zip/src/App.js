import React, { useState } from "react"
import Login from "./components/login";
import Registration from "./components/registration";
import Dashbord from "./components/dashbord";
import PasswordReset from "./components/passwordReset";


const App = () => {

  const [ deconnect, setDeconnecte ] = useState(1);

  function stateConnect () {
    if ( deconnect === 1 ) {
        return (
          <Login />
        )
    } else {
        <Dashbord />
    }
  }

  stateConnect ();

  return (
    <div className= "container">
       <Login />
    </div>
  );
}

export default App;