import "../designFolder/style.css";


// function constante pour le control des champs 
const ControlText = (input, error, typeInput) => {

    //function qui permet d'ajouter une animation, lors d'une erreur
    function addAnim() {

        err.style.animation = "dongle 1s linear"
        setTimeout(() => {
            err.style.animation = "none"
        }, 2000);
    }

    // declaration des variables et des regex 
    let err = document.querySelector(error),
        regexText = /^[a-zA-ZéêÊï_-\s]*$/,
        regexEmail = /[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]{2,4}/,
        regexTel = /^[+][0-9]*$/;
    
        let errors = 0;

    if (typeInput === "text") {

        if (input == "") {
            err.textContent = "Champs vide...";
            addAnim(error);
        } else if (regexText.test(input) == false) {
            err.textContent = "Format incorrecte..."
            addAnim(error);
        } else if (input.length < 3) {
            err.textContent = " Au moins 3 caractères"
            addAnim(error);
        } else {
            err.textContent = "";
            
        }

    }
    
    if ( typeInput === "password" ) {

        if ( input == "" ) {
            err.textContent = "Champs vide...";
            addAnim(error);
        } else if ( input.length < 6 ) {
            err.textContent = "trop court... Au moins 6 caractères"
            addAnim(error);
        } else {
            err.textContent = ""
        
        }
    }

    if ( err.textContent === "" ) {
        return true;
    }
}




export default ControlText;