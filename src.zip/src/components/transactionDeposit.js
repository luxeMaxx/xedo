import React, { useState } from "react";
import "../designFolder/style.css";


const TransactionDeposit = () => {

    const [val, setVal] = useState(0);


    //function qui permet de changer l'etat de val pour p
    //permettre l'ouverture d'une autre composant
    const changeIndex = ( e, val ) => {
        e.preventDefault ();
        setVal ( val );
    }

    if (val == 0) {
        //affichage du premier formulaire de transaction
        return (

            <div className="transaction-block" >
                <h1> Formulaire de transaction </h1>

                <div className="content-home">
                    <div className="pin"> <div></div> </div>

                    <form>

                        <div>
                            <label> Montant à envoyer </label>
                            <input type="text" name="montant"
                                placeholder="Entré le montant à envoyer"
                            />
                            <span id="sum_error" > </span>
                        </div>

                        <div>
                            <label> Pays </label>
                            <select name="pays" id="pays">
                                <option selected disabled>
                                    Sélectionnez le pays du bénéficiaire
                                </option>
                            </select>
                            <span id="country_error" ></span>
                        </div>

                        <div>
                            <label> Envoyer depuis mon compte </label>
                            <select name="compte" id="compte">
                                <option selected disabled>
                                    Sélectionnez le compte
                                </option>

                                <option value="MTN Mobile money">
                                    MTN Mobile money
                                </option>

                                <option value="Moov money">
                                    Moov money
                                </option>
                            </select>
                            <span id="compte_error" ></span>
                        </div>

                        <div>
                            <label> Numéro du compte </label>
                            <input type="tel" name="telephone"
                                placeholder=" ex: +229 0000000"
                            />
                            <span id="tel-error"></span>
                        </div>

                        <div>
                       
                            <button className="btn right-btn" onClick = { (e) => { changeIndex ( e, 1) } }>
                                 Suivant ... 
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        );
    } 
    else 
    { //affiche l'etape suivante du transaction 
        return (

            <div className="transaction-block" >
                <h1> Formulaire de transaction </h1>

                <div className="content-home">
                    <div className="pin"> <div></div> </div>

                    <form>

                        <div>
                            <label> Nom et prénom du bénéficiaire </label>
                            <input type="text" name="name_ben"
                                placeholder="Entré le nom et prénom du bénéficiaire"
                            />
                            <span id="name_error" > </span>
                        </div>

                        <div>
                            <label> Pays </label>
                            <select name="pays" id="pays">
                                <option selected disabled>
                                    Sélectionnez le pays du bénéficiaire
                                </option>
                            </select>
                            <span id="country_error" ></span>
                        </div>

                        <div>
                            <label> Envoyer sur son compte </label>
                            <select name="compte" id="compte">
                                <option selected disabled>
                                    Sélectionnez le compte
                                </option>

                                <option value="MTN Mobile money">
                                    MTN Mobile money
                                </option>

                                <option value="Moov money">
                                    Moov money
                                </option>
                            </select>
                            <span id="compte_error" ></span>
                        </div>

                        <div>
                            <label> Numéro du compte </label>
                            <input type="tel" name="telephone"
                                placeholder=" ex: +229 0000000"
                            />
                            <span id="tel-error"></span>
                        </div>

                        <div>
                            <button className="bi-chevron-left" id="btn" onClick={ (e) => changeIndex ( e, 0)}>
                                Précédent
                            </button>
                            <button className="btn" > Je valide </button>
                        </div>

                    </form>
                </div>
            </div>
        );
    }
}

export default TransactionDeposit;