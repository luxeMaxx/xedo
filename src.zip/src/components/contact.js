import React from "react";
import "../designFolder/style.css";


const Contact = () => {

    return (
        <div className = "contact-block" >
            
            <div className = "div-msg">
                <div>
                    <h1> Discussion avec les administrateurs </h1>
                </div>

                <div className = "msg-received">
                    fjjtjgthtjykukurhrthtjty
                </div>

                <div className = "msg-send">
                        efrfgrg
                </div>
                
                <div className = "msg-received">
                    fjjtjgthtjykukurhrthtjty
                </div>

                <div className = "msg-send">
                        efrfgrg
                </div>
                
                <div className = "msg-received">
                    fjjtjgthtjykukurhrthtjty
                </div>

                <div className = "msg-send">
                        efrfgrg
                </div>

            </div>
            <form>
                <input type = "text" name = "message"
                placeholder = "Formuler vos préoccupations ici ..."
                />
                <button className = "bi-send"></button>
            </form>
        </div>
    );
}

export default Contact;