import React, { useState } from "react";
import "../designFolder/style.css";


const Profile = () => {

    // etat qui permet de passer  a la page suivante en changeant l'indice
    const [ val, setVal] = useState(0);

    //fonction qui permet de changer l'etat de val
    const changeState = index => {
        setVal(index);
    }


    if (val === 0) {
        return (
            <div className="profile-block" >
                <h6> Je confirme mon compte <span className="bi-arrow-right-short"></span> </h6>
                <h1> Mon Profile </h1>

                <form>
                    <div>
                        <label>Prénom</label>
                        <input type="text" name="prenom"
                            placeholder="Votre prénom" />
                        <span className="bi-vector-pen"></span>
                        <span id="error_prenom"> </span>
                    </div>

                    <div>
                        <label>Nom</label>
                        <input type="text" name="nom"
                            placeholder="Votre nom" />
                        <span className="bi-vector-pen"></span>
                        <span id="error_nom" >  </span>
                    </div>

                    <div>
                        <label>Adresse email</label>
                        <input type="email" name="email"
                            placeholder="Votre adresse email" />
                        <span className="bi-vector-pen"></span>
                        <span id="error_email" > </span>
                    </div>

                    <div>
                        <label>Profession</label>
                        <input type="text" name="profession"
                            placeholder="Votre profession" />
                        <span className="bi-vector-pen"></span>
                        <span id="error_profession" > </span>
                    </div>

                    <div>
                        <label>Pays</label>
                        <input type="text" name="pays"
                            placeholder="Votre pays" />
                        <span className="bi-vector-pen"></span>
                        <span id="error_pays" > </span>
                    </div>

                    <div>
                        <label>Numéro de téléphone</label>
                        <input type="tel" name="telephone"
                            placeholder="Votre Numéro de télépone" />
                        <span className="bi-vector-pen"></span>
                        <span id="error_tel" >  </span>
                    </div>

                    <div>
                        <label>Mot de passe</label>
                        <input type="password" name="password"
                            placeholder="Votre mot de passe" />
                        <span className="bi-vector-pen"></span>
                        <span id="error_password" >  </span>
                    </div>

                    <button className="btn" onClick = { () => changeState (1) }>
                        Sauvergarder
                    </button>
                </form>
            </div>
        );
    } else {

        return (

            <div className="accountV-block" >
                <h1> Account validation </h1>

                <div className="content-home">

                    <form>
                        <div>
                            <label> Numéro de carte d'identité </label>
                            <input type="text" name="cardId"
                                placeholder="le numéro de carte d'identité ou passeport"
                            />
                            <span id="cardId_error"> </span>
                        </div>

                        <div>
                            <label> Profession </label>
                            <input type="text" name="profession"
                                placeholder="Votre profession"
                            />
                            <span id="profession_error">  </span>
                        </div>

                        <div>
                            <div className="" >
                                <img src="../smart_club.png" />
                            </div>
                            <button id="btn-choose-file" > Drag file here or <b>Browser</b></button>
                        </div>

                        <button className = "btn"> Je valide </button>
                    </form>

                </div>

            </div>
        );
    }
}

export default Profile;