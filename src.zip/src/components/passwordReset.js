import React, { useState } from "react";
import "../designFolder/style.css";


const pReset = () => {

   
    return (
        <div className = "preset-block" >
             <div className = "bar" >
                <hr/>
                <hr/>
                <hr/>
                <hr/>
            </div>

            <div className = "bar bar2" >
                <hr/>
                <hr/>
                <hr/>
                <hr/>
            </div>
            
            <h2> Xèdo </h2>
            <form >

                <h3>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    Modifier&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; mon mot de passe
                </h3>

                <div>
                    <label> Nouveau mot de passe </label>
                    <input type = "password" name = "new_pwd" 
                    placeholder = "Votre email ou numéro de téléphone"
                    />
                    <span id = "newpwd_error" ></span>
                </div>

                <div>
                    <label> Confirmer ce nouveau mot de passe </label>
                    <input type = "password" name = "new_pwdc" 
                    placeholder = "Votre mot de passe"
                    />
                    <span id = "newpwdc_error" ></span>
                </div>

                <button className = "btn" > Je valide </button>
               
            </form>

            <div></div>
        </div>
    );
}

export default pReset;