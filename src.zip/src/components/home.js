import React, { useState } from "react";
import "../designFolder/style.css";
import Transaction from "./transactionDeposit";

const Home = () => {

    const [val, setVal] = useState(0);

    //function qui permet de changer la valeur de val affin d'ouvrir 
    // une nouvelle contenue
    const changeIndex = index => {
        setVal ( index );
    }


    if (val === 0) // si la valeur est egale à egale 0 
    {

        return (
            <div className="home-block" >
                <h1> Bienvenue </h1>
                <button className = "btn" onClick = { () => changeIndex (1) } >
                    Envoyer de l'argent
                </button>

                <div className="content-home">

                    <div className="pin"> <div></div> </div>
                    
                    <h4> Mes transactions ( <span>6</span> ) </h4>
                    <div className="content-transaction">

                        <div className="div-rows">
                            <div className="rows-content">
                                <div>  </div>
                                <div> 500000 </div>
                                <div> </div>
                            </div>

                            <span className="send-logo">
                                
                            </span>

                            <div className="rows-content">
                                <div> </div>
                                <div> Effectué </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        );

    } else 
    {
        return <Transaction val = {val} changeIndex = {() => changeIndex()} />
    }
}

export default Home;