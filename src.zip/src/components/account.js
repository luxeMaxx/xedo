import React from "react";
import "../designFolder/style.css";

const WithDrawal = () => {

    return (
        <div className = "accountV-block" >
            <h1> Account validation </h1>

            <div className = "content-home">
                
                <form>
                    <div>
                        <label> Numéro de carte d'identité </label>
                        <input type = "text" name = "cardId"
                        placeholder = "le numéro de carte d'identité ou passeport"
                        />
                        <span id = "cardId_error"> </span>
                    </div>

                    <div>
                        <label> Profession </label>
                        <input type = "text" name = "profession"
                        placeholder = "Votre profession"
                        />
                        <span id = "profession_error"> </span>
                    </div>

                    <div>
                        <div className = "" >
                            <img src = "../smart_club.png" />
                        </div>
                        <button id = "btn-choose-file" > Drag file here or <b>Browser</b></button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default WithDrawal;