import React, { useState } from "react";
import "../designFolder/style.css";
import { BrowserRouter as Router, Route, span, Switch } from "react-router-dom";
import Profile from "./profile";
import TransactionDeposit from "./transactionDeposit";
import Contact from "./contact";
import AccountValidation from "./account";
import Home from "./home";


const Dashbord = () => {

    const [ tab, setTab ] = useState (0);


    // function qui permet de modifier l'etat de tab,
    // lors d'un clicksur un bouton
    const showTabIndex = index => {
        setTab ( index );
    }

    ///function qui permet d'ouvrir les contenus de chanque onglets
    function showTabsContent () {

        var allBtn = document.querySelectorAll ( "nav button" );
         for ( var i = 0; i < allBtn.length; i++ ) {
             allBtn[i].style.boxShadow = "none";
             allBtn[i].style.border = "none";
         }

        if ( tab === 1 ) 
        {
            allBtn[0].style.boxShadow = "0 0 10px #4e2679";
            allBtn[0].style.border = "1px solid #4e267980";
            return (
                <Home />
            )
        } else if ( tab === 2 ) 
        {
            allBtn[1].style.boxShadow = "0 0 10px #4e2679"
            allBtn[1].style.border = "1px solid #4e267980";;
            return (
                <Profile />
            )
        } else if ( tab === 3 ) 
        {
            allBtn[2].style.boxShadow = "0 0 10px #4e2679";
            allBtn[2].style.border = "1px solid #4e267980";

            return (
                <div> ça marche comme tu le sais</div>
            )
        }else if ( tab === 4 ) 
        {
            allBtn[3].style.boxShadow = "0 0 10px #4e2679";
            allBtn[3].style.border = "1px solid #4e267980";
            return (
                <Contact />
            )
        } else if ( tab === 5 ) 
        {
            allBtn[4].style.boxShadow = "0 0 10px #4e2679";
            allBtn[4].style.border = "1px solid #4e267980";
            
        } else {
            return (
                <Home />
            )
        }
    }


    return (
        <div className="dashbord-block" >

            <div className="block-left">
                <h2> Xèdo </h2>

                <nav>

                    <button onClick = { () => showTabIndex (1)} >
                        <span className="bi-house-door-fill"></span>
                        <span> Accueil </span>
                    </button>

                    <button onClick = { () => showTabIndex (2)}>
                        <span className="bi-person"></span>
                        <span> Mon profile </span>
                    </button>

                    <button onClick = { () => showTabIndex (3)}>
                        <span className="bi-question-circle"></span>
                        <span> Comment ça &nbsp;&nbsp;&nbsp;marche ? </span>
                    </button>

                    <button onClick = { () => showTabIndex (4)}>
                        <span className="bi-envelope"></span>
                        <span> Nous contacter </span>
                    </button>

                    <button onClick = { () => showTabIndex (5)}>
                        <span className="bi-power"></span>
                        <span > Se déconnecter </span>
                    </button>

                </nav>
            </div>

            <div className = "tab-content" >
                   { showTabsContent () }
            </div>
            <p className = "text-footer">Développé par <b>Smart club </b> </p>
        </div>
    );
}

export default Dashbord;