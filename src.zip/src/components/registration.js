import React, { useState } from "react";
import "../designFolder/style.css";
import "../../node_modules/bootstrap-icons/font/bootstrap-icons.css";
import Login from "./login";
import ControlValue from "../controlForm/controlForm";


const Registration = () => {

    // etat qui permet de passer  a la page suivante en changeant l'indice
    const [val, setVal] = useState(0);

    //fonction qui permet de changer l'etat de val
    const changeState = index => {
        setVal(index);
    }

    // const des etat des champs du formulaire d'incription
    const [ valueIns, setValuesIns ] = useState({
        prenom: "",
        nom: "",
        email: "",
        pays: "",
        telephone: "",
        password: "",
        passwordC: ""
    })

    // function de changement d'etat des champs
    const handleChangeIns = e => {
        setValuesIns ({
            ...valueIns,
            [ e.target.name] : e.target.value
        })
    }


    //function de validation lors d'un click sur le bouton
    const handleSubmitIns = e => {
        e.preventDefault ();


    }

    var logo1 = (
        <img src="./smart.png" />
    );

    if (val === 1) { // si l'etat de val est a 1, on affiche la page de connexion
        return (
            <Login />
        )
    }
    else { // sinon, on reste sur la page d'inscription
        return (
            <div className="signup-block" >

                <div className="head-block">
                    <h2> Xèdo</h2>
                    <p>
                        <span> Inscrivez-vous gratuitement </span>
                        <span> et découvrez Xèdo dès aujourd'hui </span>
                    </p>
                    <div className="div-btn-connect" >
                        J'ai déjà un compte.
                        <button onClick={() => changeState(1)} >
                            Se connecter
                        </button>
                    </div>
                </div>

                <div className="block-info-form">
                    <div className="div-infos">
                        <h3>
                            <span className="bi-person-circle"></span>
                            Compte gratuit
                        </h3>
                        <p>
                            Download Free icons and Free Icon Packs.
                            More than 500000 icons in PNG, ICO and
                            ICNS icons for Mac +2000 icon pack for fr.
                        </p>
                    </div>

                    <div className="div-infos">
                        <h3>
                            <span className="bi-nut"></span>
                            Votre application
                        </h3>

                        <p>
                            Iconfinder is a web company whose man
                            product is a search engine for icons.
                            The Company was founded in 2007 by Martin
                            Le Blanc Eigtved. Iconfinder gained populary after
                            a relaunch in 2009 and is now the langest
                            icon search engine with more than 2 million unique
                            users per month. Inconfinder received $1.5 M in funding
                            from the Danish venture capital fund.
                        </p>
                    </div>

                    <div className="logo" >
                        {logo1}
                    </div>

                </div>

                <div className="form" >
                    <form >
                        <div>
                            <label> Prénom </label>
                            <input type="text" name="prenom"
                            id = "prenom"
                            placeholder="Entrez votre prénom"
                            value = { valueIns.prenom }
                            onChange = { handleChangeIns }
                            />
                            <span id="error_prenom"> gigug</span>
                        </div>

                        <div>
                            <label> Nom </label>
                            <input type="text" name="nom"
                            id = "nom"
                            placeholder="Entrez votre nom"
                            value = { valueIns.nom }
                            onChange = { handleChangeIns }
                            />
                            <span id="error_nom"> </span>
                        </div>

                        <div>
                            <label> Adresse email </label>
                            <input type="email" name="email"
                            id = "email"
                            placeholder="Votre email fonctionnelle"
                            value = { valueIns.email }
                            onChange = { handleChangeIns }
                            />
                            <span id="email_error"> </span>
                        </div>

                        <div>
                            <label> Pays </label>
                            <select name="pays" 
                            id="pays"
                            value = { valueIns.pays }
                            onChange = { handleChangeIns }>
                                <option selected disabled > Votre Pays </option>
                            </select>
                            <span id="error_pays"> </span>
                        </div>

                        <div>
                            <label> Numéro de téléphone </label>
                            <input type="tel" name="telephone"
                            id = "telephone"
                            placeholder="ex: +229 00 00 00 00"
                            value = { valueIns.telephone }
                            onChange = { handleChangeIns }
                            />
                            <span id="tel_error"> </span>
                        </div>

                        <div>
                            <label> Mot de passe </label>
                            <input type="password" name="paswword"
                            id = "password"
                            placeholder="Saisissez un mot de passe"
                            value = { valueIns.password }
                            onChange = { handleChangeIns }
                            />
                            <span id="pwd_error">  </span>
                        </div>

                        <div>
                            <label> Confirmer votre mot de passe </label>
                            <input type="password" name="passwordC"
                            id = "passwordC"
                            placeholder="Resaisissez le mème mot de passe"
                            value = { valueIns.passwordC }
                            onChange = { handleChangeIns }
                            />
                            <span id="pwdc_error">  </span>
                        </div>

                        <button className="btn" onClick = { handleSubmitIns } >
                            Je valide 
                        </button>

                        <p>
                            L'inscription signifie que vous avez lu et accepté
                            les <a href="#" > condictions d'utilisation </a>
                            et notre <a href="#" > politique de confidentialité. </a>
                        </p>
                    </form>
                </div>
            </div>
        );
    }
}

export default Registration;