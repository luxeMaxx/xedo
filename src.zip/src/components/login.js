import React, { useState } from "react";
import "../designFolder/style.css";
import Registration from "./registration";
import ControlValue from "../controlForm/controlForm";
import Dashbord from "./dashbord";


const Login = () => {

    // etat qui permet de passer  a la page suivante en changeant l'indice
    const [val, setVal] = useState(0);

    //fonction qui permet de changer l'etat de val
    const changeState = index => {
        setVal(index);
    }

    //constante pour la gestion des etat des champs des formulaire
    const [ value, setValue ] = useState ({
        user_id: "",
        user_pwd: ""
    });

    const [ value2, setValue2 ] = useState ({
        new_pwd: "",
        new_pwdc: ""
    });


    // function qui control la mise à jour ou l'etat de champs..
    const handleChange = e => {
        setValue ({
            ...value, 
            [ e.target.name ] : e.target.value
        })
    }

    const handleChange2 = e => {
        setValue2 ({
            ...value2, 
            [ e.target.name ] : e.target.value
        })
    }

    // function qui se declenche quand on appuie sur les bouton

    //bouton du premier formulaire
    const handleSubmit = e => {
        e.preventDefault ();
        
        ControlValue ( value.user_id, "#userId_error", "text" )
        ControlValue ( value.user_pwd, "#pwd_error", "password" )
        if (
            ControlValue ( value.user_id, "#userId_error", "text" ) &&
            ControlValue ( value.user_pwd, "#pwd_error", "password" ) )
        {
            return (
                <Dashbord />
            )
        }
    }

    //bouton du deuxième formulaire
    const handleSubmit2 = e => {
        e.preventDefault ();
        
        ControlValue ( value2.new_pwd, "#newpwd_error", "password" )
        ControlValue ( value2.new_pwdc, "#newpwdc_error", "password" )
        if (
            ControlValue ( value2.new_pwd, "#newpwd_error", "password" ) &&
            ControlValue ( value2.new_pwdc, "#newpwdc_error", "password" ) )
        {
            if ( value2.new_pwd === value2.new_pwdc ){
                
                alert ( "ok" );
            }
            else {
                document.getElementById ( "newpwdc_error" ).textContent
                = "les mots de passe ne sont pas identique.."
            }
        }
    }


    
    if (val === 0) { // si val = 0, on affiche la page de depart
        return (

            <div className="login-block" >
                <div className="bar" >
                    <hr />
                    <hr />
                    <hr />
                    <hr />
                </div>

                <div className="bar bar2" >
                    <hr />
                    <hr />
                    <hr />
                    <hr />
                </div>

                <h2> Xèdo </h2>
                <form >

                    <h3> Se connecter </h3>

                    <div>
                        <label> Identifiant </label>
                        <input type="text" name="user_id"
                        id="user_id"
                        placeholder="Votre email ou numéro de téléphone"
                        value = { value.user_id }
                        onChange = {handleChange}
                        />
                        <span id="userId_error" ></span>
                    </div>

                    <div>
                        <label> Mot de passe </label>
                        <input type="password" name="user_pwd"
                        id="user_pwd"
                        placeholder="Votre mot de passe"
                        value = { value.user_pwd }
                        onChange = {handleChange}
                        />
                        <span id="pwd_error" ></span>
                    </div>

                    <button onClick = {handleSubmit} > Je valide </button>
                    <a onClick = {() => changeState(1)}>
                        J'ai oublié mon mot de passe
                    </a>
                </form>

                <div>
                    <a onClick={() => changeState(2)}> Je suis nouveau à Xèdo! </a>
                </div>
            </div>
        );
    }
    else if (val === 1) { // sinon si, val = 1, on affiche la page de réinitialisation du mot de passe
       
        return (
            <div className = "preset-block" >
             <div className = "bar" >
                <hr/>
                <hr/>
                <hr/>
                <hr/>
            </div>

            <div className = "bar bar2" >
                <hr/>
                <hr/>
                <hr/>
                <hr/>
            </div>
            
            <h2> Xèdo </h2>
            <form >

                <h3>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    Modifier&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; mon mot de passe
                </h3>

                <div>
                    <label> Nouveau mot de passe </label>
                    <input type = "password" name = "new_pwd" 
                    id = "new_pwd"
                    placeholder = "Entrer un nouveau mot de passe"
                    value = { value2.new_pwd }
                    onChange = { handleChange2 }
                    />
                    <span id = "newpwd_error" ></span>
                </div>

                <div>
                    <label> Confirmer ce nouveau mot de passe </label>
                    <input type = "password" name = "new_pwdc" 
                    id = "new_pwdc"
                    placeholder = "Retaper le mème mot de passe"
                    value = { value2.new_pwdc}
                    onChange = { handleChange2 }
                    />
                    <span id = "newpwdc_error" ></span>
                </div>

                <button className = "btn" onClick = { handleSubmit2 }>
                     Je valide 
                </button>
               
            </form>

            <div></div>
        </div>
        )
    }

    else // sinon, on affiche la page d'inscription
    {
       return (
           <Registration />
       )
    }
}

export default Login;